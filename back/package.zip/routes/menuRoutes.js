const express = require('express');
const router = express.Router();

// GET: Retrieve the menu for a specific restaurant
router.get('/:restaurantId/menu', (req, res) => {
  // Example response (replace this with actual logic later)
  res.status(200).json({ message: `Fetching menu for restaurant ${req.params.restaurantId}` });
});

// POST: Add a new category or items to the restaurant's menu
router.post('/:restaurantId/menu', (req, res) => {
  // Example response (replace this with actual logic later)
  res.status(201).json({
    message: `Adding menu to restaurant ${req.params.restaurantId}`,
    data: req.body,
  });
});

module.exports = router;