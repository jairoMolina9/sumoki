const mongoose = require('mongoose');

// Menu Item Schema
const MenuItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    default: '',
  },
  price: {
    type: Number,
    required: true,
    min: 0,
  },
});

// Menu Category Schema
const MenuCategorySchema = new mongoose.Schema({
  category: {
    type: String,
    required: true,
  },
  items: [MenuItemSchema], // Embed menu items
});

// Restaurant Schema
const RestaurantSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  location: {
    address: {
      type: String,
      required: true,
    },
    city: {
      type: String,
      required: true,
    },
    state: {
      type: String,
      required: true,
    },
    zip: {
      type: String,
      required: true,
    },
  },
  contact: {
    phone: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: false,
    },
  },
  menu: [MenuCategorySchema], // Embed menu categories
});

// Export the Restaurant model
const Restaurant = mongoose.model('Restaurant', RestaurantSchema);

module.exports = Restaurant;